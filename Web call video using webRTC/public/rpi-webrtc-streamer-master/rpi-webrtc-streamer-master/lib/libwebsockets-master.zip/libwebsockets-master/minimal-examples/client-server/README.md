|name|demonstrates|
---|---
minimal-ws-proxy|Serves an index.html over http that connects back to the ws server, and maintains a ws client connection of its own at the same time to https://libwebsockets.org dumb-increment-protocol to feed a ringbuffer that is sent to all connected browsers.
